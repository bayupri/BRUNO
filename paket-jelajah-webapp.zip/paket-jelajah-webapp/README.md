# Paket Jelajah Web App (POC)

## Cara Jalankan

### Backend
```
cd paket-jelajah-webapp/backend
npm i
npm run seed
npm run dev
```
Backend: http://localhost:4000

### Frontend
```
cd paket-jelajah-webapp/frontend
npm i
npm run dev
```
Buka URL Vite yang tampil (biasanya http://localhost:5173).

## Catatan
- Database lokal: `backend/data.sqlite` (otomatis dibuat).
- Tiket valid (mock): format `KAI` + 3-7 huruf/angka, contoh: `KAIXYZ12`.