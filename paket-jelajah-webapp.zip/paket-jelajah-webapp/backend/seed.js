// seed.js
import { getDb } from './db.js';

const sampleAds = [
  {
    title: 'Paket Jelajah 7 Hari',
    subtitle: 'Kuota 20GB + Akses Apps',
    description: 'Paket bundling hemat untuk perjalanan 7 hari.',
    price: 75000,
    image_url: 'https://picsum.photos/seed/jelajah7/600/300',
    tags: 'paket-jelajah,train,bundle'
  },
  {
    title: 'Paket Jelajah Weekend',
    subtitle: 'Kuota 10GB',
    description: 'Cocok untuk short trip weekend.',
    price: 35000,
    image_url: 'https://picsum.photos/seed/weekend/600/300',
    tags: 'paket-jelajah,train'
  }
];

async function run() {
  const db = await getDb();
  await db.run(`INSERT OR IGNORE INTO users (id, msisdn, name) VALUES (1,'6281234567890','Demo User')`);
  await db.run(`INSERT OR IGNORE INTO whitelist (user_id, is_whitelisted, lba_segment) VALUES (1,1,'LBA-TRAIN-LOYAL')`);
  for (const a of sampleAds) {
    await db.run(
      `INSERT INTO ads (title, subtitle, description, price, image_url, tags) VALUES (?,?,?,?,?,?)`,
      [a.title, a.subtitle, a.description, a.price, a.image_url, a.tags]
    );
  }
  await db.run(`INSERT OR IGNORE INTO train_clusters (code, name) VALUES ('JKT-CL1','Jakarta Cluster 1')`);
  console.log('Seed done.');
  await db.close();
}
run();