// server.js
import express from 'express';
import cors from 'cors';
import { getDb } from './db.js';

const app = express();
app.use(cors());
app.use(express.json());

const isPaketJelajah = (row) =>
  (row.tags || '').split(',').map(t => t.trim()).includes('paket-jelajah');

app.get('/ads/promos/paket-jelajah/notification', async (req, res) => {
  const userId = Number(req.query.user_id || 1);
  const db = await getDb();
  const wl = await db.get(`SELECT * FROM whitelist WHERE user_id = ?`, [userId]);
  const ads = await db.all(`SELECT * FROM ads WHERE is_active = 1 ORDER BY id DESC`);
  const promos = ads.filter(isPaketJelajah);
  let pick = promos.slice(0, 2);
  if (wl?.is_whitelisted) {
    pick = promos.slice(0, 3);
  }
  res.json({ user_id: userId, items: pick });
});

app.get('/ads/promos/paket-jelajah', async (_req, res) => {
  const db = await getDb();
  const ads = await db.all(`SELECT * FROM ads WHERE is_active = 1 ORDER BY id DESC`);
  res.json(ads.filter(isPaketJelajah));
});

app.get('/ads/promos/paket-jelajah/:id', async (req, res) => {
  const db = await getDb();
  const ad = await db.get(`SELECT * FROM ads WHERE id = ?`, [req.params.id]);
  if (!ad || !isPaketJelajah(ad)) return res.status(404).json({ message: 'Not found' });
  res.json(ad);
});

app.post('/ads/clicks/paket-jelajah', async (req, res) => {
  const { ad_id, user_id, source } = req.body || {};
  if (!ad_id || !user_id) return res.status(400).json({ message: 'ad_id and user_id required' });
  const db = await getDb();
  await db.run(`INSERT INTO clicks (ad_id, user_id, source) VALUES (?,?,?)`, [ad_id, user_id, source || 'unknown']);
  res.json({ ok: true });
});

app.get('/ads/network/partner/whitelist/:user_id', async (req, res) => {
  const db = await getDb();
  const row = await db.get(
    `SELECT u.id as user_id, COALESCE(w.is_whitelisted,0) as is_whitelisted, w.lba_segment
     FROM users u LEFT JOIN whitelist w ON u.id = w.user_id WHERE u.id = ?`,
    [req.params.user_id]
  );
  if (!row) return res.status(404).json({ message: 'User not found' });
  res.json(row);
});

app.post('/ads/bundling/train-ticket', async (req, res) => {
  const { user_id, ad_id, train_ticket_no } = req.body || {};
  if (!user_id || !ad_id) return res.status(400).json({ message: 'user_id and ad_id required' });

  const db = await getDb();
  const ad = await db.get(`SELECT * FROM ads WHERE id = ?`, [ad_id]);
  if (!ad || !isPaketJelajah(ad)) return res.status(404).json({ message: 'Promo not found' });

  let status = 'draft';
  let ticket = train_ticket_no || null;

  if (train_ticket_no) {
    const valid = /^KAI[A-Z0-9]{3,7}$/.test(train_ticket_no);
    status = valid ? 'paired' : 'failed';
  }

  const result = await db.run(
    `INSERT INTO bundles (user_id, ad_id, train_ticket_no, status) VALUES (?,?,?,?)`,
    [user_id, ad_id, ticket, status]
  );
  const bundle = await db.get(`SELECT * FROM bundles WHERE id = ?`, [result.lastID]);
  res.json(bundle);
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Backend running on http://localhost:${PORT}`));