import React, { useEffect, useState } from 'react'
import { createRoot } from 'react-dom/client'

const API = 'http://localhost:4000'
const DEMO_USER_ID = 1

function App() {
  const [notifPromos, setNotifPromos] = useState([])
  const [promos, setPromos] = useState([])
  const [detail, setDetail] = useState(null)
  const [ticketNo, setTicketNo] = useState('')
  const [bundle, setBundle] = useState(null)
  const [wl, setWl] = useState(null)

  useEffect(() => {
    fetch(`${API}/ads/promos/paket-jelajah/notification?user_id=${DEMO_USER_ID}`)
      .then(r => r.json()).then(setNotifPromos)
    fetch(`${API}/ads/promos/paket-jelajah`)
      .then(r => r.json()).then(setPromos)
    fetch(`${API}/ads/network/partner/whitelist/${DEMO_USER_ID}`)
      .then(r => r.json()).then(setWl)
  }, [])

  const openDetail = async (ad) => {
    const r = await fetch(`${API}/ads/promos/paket-jelajah/${ad.id}`)
    const d = await r.json()
    setDetail(d)
    await fetch(`${API}/ads/clicks/paket-jelajah`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ ad_id: ad.id, user_id: DEMO_USER_ID, source: 'detail' })
    })
  }

  const createBundle = async () => {
    const r = await fetch(`${API}/ads/bundling/train-ticket`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ user_id: DEMO_USER_ID, ad_id: detail.id, train_ticket_no: ticketNo || undefined })
    })
    const b = await r.json()
    setBundle(b)
  }

  return (
    <div className="container">
      <section>
        <h3>Notifikasi Promo</h3>
        <div className="row">
          {(notifPromos.items || []).map(p => (
            <div key={p.id} className="card">
              <img src={p.image_url} />
              <div>
                <h4>{p.title}</h4>
                <div>{p.subtitle}</div>
                <div>Rp {p.price?.toLocaleString('id-ID')}</div>
                <div className="row">
                  <button onClick={() => openDetail(p)}>Lihat</button>
                  <button className="secondary"
                    onClick={() => fetch(`${API}/ads/clicks/paket-jelajah`, {
                      method: 'POST', headers: {'Content-Type':'application/json'},
                      body: JSON.stringify({ ad_id: p.id, user_id: DEMO_USER_ID, source: 'notification' })
                    })}
                  >Saya Tertarik</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h3>Daftar Promo</h3>
        {promos.map(p => (
          <div key={p.id} className="card">
            <img src={p.image_url} />
            <div>
              <h4>{p.title}</h4>
              <div>{p.subtitle}</div>
              <div>Rp {p.price?.toLocaleString('id-ID')}</div>
              <button onClick={() => openDetail(p)}>Detail</button>
            </div>
          </div>
        ))}
      </section>

      {detail && (
        <section>
          <h3>Detail Promo</h3>
          <div className="card">
            <img src={detail.image_url} />
            <div>
              <h4>{detail.title}</h4>
              <div>{detail.description}</div>
              <div>Harga: Rp {detail.price?.toLocaleString('id-ID')}</div>
              <div className="row">
                <input placeholder="Masukkan No. Tiket KAI (contoh: KAIXYZ12)"
                       value={ticketNo} onChange={e => setTicketNo(e.target.value)} />
                <button onClick={createBundle}>Bundling dengan Tiket</button>
              </div>
              {bundle && (
                <p>Status Bundling: <b>{bundle.status}</b> {bundle.train_ticket_no ? `(Ticket ${bundle.train_ticket_no})` : ''}</p>
              )}
            </div>
          </div>
        </section>
      )}

      {wl && (
        <section>
          <h3>Status Whitelist</h3>
          <p>User #{wl.user_id}: {wl.is_whitelisted ? 'Whitelisted' : 'Non-Whitelist'}</p>
          {wl.lba_segment && <p>Segment: {wl.lba_segment}</p>}
        </section>
      )}
    </div>
  )
}

createRoot(document.getElementById('root')).render(<App />)